from django.forms import ModelForm
from .models import Employee

class EmployeeForm(ModelForm):
        class Meta:
            model = Employee
            fields = '__all__'
            # exclude =(' nombre del campo ') se usa para excluir uno o varios campos.
            
    

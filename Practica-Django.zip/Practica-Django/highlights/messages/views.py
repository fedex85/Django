from django.shortcuts import render
from django.contrib import messages

def message(request):
    messages.success(request, "Hola, soy un pinche mensaje")
    return render(request, 'message.html', {})

from django.apps import AppConfig


class OptionalParametersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'optional_parameters'

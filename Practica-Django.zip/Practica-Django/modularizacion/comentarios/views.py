from django.shortcuts import render
from django.http import HttpResponse
from .models import Comment

def test(request):
    return HttpResponse("Funciona correctamente")
 
def create(request):
    #comment = Comment(name="Federico",score=5, comment="Comentame este" )
    #comment.save()
    comment = Comment.objects.create(name="Jeanny")
    return  HttpResponse("Ruta para probar los modelos")

def delete(request):
    #comment = Comment.objects.get(id=4)
    #comment.delete()
    Comment.objects.filter(id=3).delete()
    return HttpResponse("Ruta para probar los borrados")
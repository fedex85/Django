from django.shortcuts import render
from django.http import HttpResponse
from .models import Reporter, Article  
from datetime import date 

def create(request):
    rep = Reporter(first_name='Federico', last_name='Serra', email='laburra@demo.com')
    rep.save()
    
    art1 = Article(headline='Mors is principium', pub_date=date(2022,5,5,), reporter=rep )
    art1.save()
    art2 = Article(headline='Mors is empezando', pub_date=date(2022,5,10,), reporter=rep )
    art2.save()
    art3 = Article(headline='Mors is terminando', pub_date=date(2022,8,5,), reporter=rep )
    art3.save()
    
    result = rep.article_set.count()
    #result = rep.article_set.filter(headline= 'Mors is empezando')
    #result = rep.article_set.all()
    #result = art1.reporter.first_name
   
   
    
    
    return HttpResponse(result)
